const String splashText = """
 Watch your favorite movies or series on
 only one platform. you can watch it
 anytime and anywhere.

 """;
