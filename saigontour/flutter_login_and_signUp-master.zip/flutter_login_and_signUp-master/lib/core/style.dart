import 'package:flutter/material.dart';

class Stlyes {
  static ThemeData themeData() {
    return ThemeData(
      fontFamily: 'SF Pro',
      primarySwatch: Colors.blue,
    );
  }
}
