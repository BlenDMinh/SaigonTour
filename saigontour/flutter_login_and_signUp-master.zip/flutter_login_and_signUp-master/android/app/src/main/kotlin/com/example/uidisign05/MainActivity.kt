package com.example.uidisign05

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
